function concatenate(array) {
    return array.join('');
}

module.exports = concatenate;
