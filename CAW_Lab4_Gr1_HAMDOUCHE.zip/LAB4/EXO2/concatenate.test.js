const concatenate = require('./concatenate');

describe("concatenate function", () => {
    test("concatenates all elements of an array with no separator", () => {
        const colors = ["Red", "Green", "White", "Black"];
        expect(concatenate(colors)).toBe("RedGreenWhiteBlack");
    });

    test("returns an empty string if array is empty", () => {
        expect(concatenate([])).toBe("");
    });
});
