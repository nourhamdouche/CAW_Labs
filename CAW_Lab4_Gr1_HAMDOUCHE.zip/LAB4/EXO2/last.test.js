const last = require('./last');

describe("last function", () => {
    test("returns the last 3 elements of the array", () => {
        const array = [1, 2, 3, 4, 5];
        expect(last(array, 3)).toEqual([3, 4, 5]);
    });

    test("returns an empty array if array is null", () => {
        expect(last(null, 3)).toEqual([]);
    });

    test("returns the last element if n is not provided", () => {
        expect(last([1, 2, 3])).toBe(3);
    });
});
