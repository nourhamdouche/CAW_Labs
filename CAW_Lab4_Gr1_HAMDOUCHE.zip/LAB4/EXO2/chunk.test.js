const chunk = require('./chunk');

describe("chunk function", () => {
    test("divides the array into sub-arrays of size 2", () => {
        const array = [1, 2, 3, 4, 5];
        expect(chunk(array, 2)).toEqual([[1, 2], [3, 4], [5]]);
    });

    test("returns an empty array if array is empty", () => {
        expect(chunk([], 2)).toEqual([]);
    });

    test("returns the full array in one chunk if size is larger than array length", () => {
        const array = [1, 2, 3];
        expect(chunk(array, 5)).toEqual([[1, 2, 3]]);
    });
});
