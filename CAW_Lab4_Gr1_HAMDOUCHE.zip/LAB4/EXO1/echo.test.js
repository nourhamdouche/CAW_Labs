const exf = require('./echo.js');

describe("exf function", () => {
    let consoleSpy;

    beforeEach(() => {
        consoleSpy = jest.spyOn(console, 'log').mockImplementation();
    });

    afterEach(() => {
        consoleSpy.mockRestore();
    });

    test("should log 'echo' 5 times", () => {
        exf("echo", 5);
        expect(consoleSpy).toHaveBeenCalledTimes(5);
        expect(consoleSpy).toHaveBeenCalledWith("echo");
    });

    test("should log 'JS from server' 10 times", () => {
        exf("JS from server", 10);
        expect(consoleSpy).toHaveBeenCalledTimes(10);
        expect(consoleSpy).toHaveBeenCalledWith("JS from server");
    });
});
