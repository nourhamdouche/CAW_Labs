const mean = require('./notation');

describe("mean function", () => {
    test("calculates the average of an array of scores", () => {
        const scores = [18, 15, 9, 14, 18.5];
        const result = mean(scores);
        expect(result).toBeCloseTo(14.9); 
    });

    test("returns 0 for an empty array", () => {
        const result = mean([]);
        expect(result).toBe(0);
    });

    test("returns 0 if input is not an array", () => {
        const result = mean("not an array");
        expect(result).toBe(0);
    });
});
